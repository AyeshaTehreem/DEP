import { createRoot } from 'react-dom/client';
import App from './App'; // Adjust the path as per your application structure

const root = createRoot(document.getElementById('root'));
root.render(<App />);
