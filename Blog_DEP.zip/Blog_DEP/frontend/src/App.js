import React, { useState } from 'react';
import BlogForm from './components/BlogForm';
import BlogList from './components/BlogList';
import './App.css';  // Import the CSS file

function App() {
  const [blogs, setBlogs] = useState([]);

  const handleBlogCreated = (newBlog) => {
    setBlogs([...blogs, newBlog]);
  };

  return (
    <div className="App">
      <BlogForm onBlogCreated={handleBlogCreated} />
      <BlogList />
    </div>
  );
}

export default App;
