import React from 'react';
import BlogForm from '../components/BlogForm';
import { createBlog } from '../services/blogService';
import { useNavigate } from 'react-router-dom';

const NewBlog = () => {
  const navigate = useNavigate();

  const handleSubmit = async (blog) => {
    try {
      await createBlog(blog);
      navigate('/');
    } catch (error) {
      console.error('Error creating blog:', error);
    }
  };

  return (
    <div>
      <h1>New Blog</h1>
      <BlogForm onSubmit={handleSubmit} />
    </div>
  );
};

export default NewBlog;
