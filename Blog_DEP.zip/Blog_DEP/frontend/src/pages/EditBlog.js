import React, { useEffect, useState } from 'react';
import BlogForm from '../components/BlogForm';
import { getBlog, updateBlog } from '../services/blogService';
import { useNavigate, useParams } from 'react-router-dom';

const EditBlog = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [initialData, setInitialData] = useState(null);

  useEffect(() => {
    const fetchBlog = async () => {
      try {
        const response = await getBlog(id);
        setInitialData(response.data);
      } catch (error) {
        console.error('Error fetching blog:', error);
      }
    };
    fetchBlog();
  }, [id]);

  const handleSubmit = async (blog) => {
    try {
      await updateBlog(id, blog);
      navigate(`/blogs/${id}`);
    } catch (error) {
      console.error('Error updating blog:', error);
    }
  };

  return (
    <div>
      <h1>Edit Blog</h1>
      {initialData && <BlogForm initialData={initialData} onSubmit={handleSubmit} />}
    </div>
  );
};

export default EditBlog;
