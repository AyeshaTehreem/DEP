import React, { useState } from 'react';
import blogService from '../services/blogService';
import './blogStyle.css'; // Import CSS file

function BlogForm({ onBlogCreated }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [showPopup, setShowPopup] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newBlog = await blogService.create({ title, content });
    setTitle('');
    setContent('');
    setShowPopup(true);
    setTimeout(() => setShowPopup(false), 3000);
    onBlogCreated(newBlog);
  };

  return (
    <div className="blog-container">
      <form className="blog-form" onSubmit={handleSubmit}>
        <div>
          <label>Title</label>
          <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div>
          <label>Content</label>
          <textarea value={content} onChange={(e) => setContent(e.target.value)} />
        </div>
        <button type="submit">Create Blog</button>
      </form>
      {showPopup && <div className="popup">Blog added to DB</div>}
    </div>
  );
}

export default BlogForm;
