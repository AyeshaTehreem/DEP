import React, { useState, useEffect } from 'react';
import blogService from '../services/blogService';
import './blogStyle.css'; // Import CSS file

function BlogList() {
  const [blogs, setBlogs] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [currentBlog, setCurrentBlog] = useState({});

  useEffect(() => {
    fetchBlogs();
  }, []);

  const fetchBlogs = async () => {
    try {
      const fetchedBlogs = await blogService.getAll();
      setBlogs(fetchedBlogs);
    } catch (error) {
      console.error('Error fetching blogs:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await blogService.remove(id);
      setBlogs(blogs.filter(blog => blog._id !== id));
    } catch (error) {
      console.error('Error deleting blog:', error);
    }
  };

  const handleEdit = (blog) => {
    setIsEditing(true);
    setCurrentBlog(blog);
  };

  const handleUpdate = async () => {
    try {
      const updatedBlog = await blogService.update(currentBlog._id, currentBlog);
      setBlogs(blogs.map(blog => (blog._id === updatedBlog._id ? updatedBlog : blog)));
      setIsEditing(false);
      setCurrentBlog({});
    } catch (error) {
      console.error('Error updating blog:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentBlog({ ...currentBlog, [name]: value });
  };

  return (
    <div className="blog-container">
      <button className="fetch-button" onClick={fetchBlogs}>Show All Blogs</button>
      {blogs.length > 0 && (
        <div className="blog-list">
          <h1>Blogs</h1>
          {blogs.map((blog) => (
            <div key={blog._id} className="blog-item">
              <h2>{blog.title}</h2>
              <p>{blog.content}</p>
              <button onClick={() => handleDelete(blog._id)}>Delete</button>
              <button onClick={() => handleEdit(blog)}>Edit</button>
            </div>
          ))}
        </div>
      )}
      {isEditing && (
        <div className="edit-form">
          <h2>Edit Blog</h2>
          <input
            type="text"
            name="title"
            value={currentBlog.title}
            onChange={handleChange}
            placeholder="Title"
          />
          <textarea
            name="content"
            value={currentBlog.content}
            onChange={handleChange}
            placeholder="Content"
          />
          <button onClick={handleUpdate}>Save</button>
          <button onClick={() => setIsEditing(false)}>Cancel</button>
        </div>
      )}
    </div>
  );
}

export default BlogList;
